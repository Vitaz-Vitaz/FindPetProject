package com.example.findpet.ForData;

import android.widget.ImageView;

import java.util.ArrayList;

public class Data {

   public static final ArrayList<Double> x = new ArrayList<>();
    public static final ArrayList<Double> y = new ArrayList<>();
    public static final ArrayList<String> description = new ArrayList<>();
    public static final ArrayList<ImageView> photo = new ArrayList<android.widget.ImageView>();
    public static double dataX = 0;
    public static double dataY = 0;
    public static double dataXForShow = 0;
    public static double dataYForShow = 0;
    public static String DesWhatToShow = "";
    public static String status = "";
 public static String status2 = "";
 public static int type = 0;
 public static int k = 0;

 public static long i;
}
